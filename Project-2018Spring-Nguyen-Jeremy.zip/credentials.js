module.exports = {
	nasaKey: 'CbVMVyCJmocpuCtI9fVueHQoUOaswGiSovWoqqmC'
}